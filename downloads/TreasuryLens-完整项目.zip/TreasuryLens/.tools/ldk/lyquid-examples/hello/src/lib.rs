//! Greeting Lyquid that shows the network/instance state split.
//!
//! Network methods initialize and update the shared greeting plus a network-wide greeting count,
//! including Ethereum-exported entry points. The instance method `greet_me` reads that network
//! state while updating an instance `HashMap` keyed by caller, making the difference between
//! sequenced shared state and per-instance caller counters visible in one small contract.

use lyquid::prelude::*;

state! {
    network greeting: String = String::new();
    network greet_count: u64 = 0;
    // Off-chain state
    instance per_user_count: HashMap<Address, u64> = new_hashmap();
}

#[method::network(export = eth)]
fn constructor(ctx: &mut _, greeting: String) {
    *ctx.network.greeting = greeting;
}

#[method::network(export = eth)]
fn set_greeting(ctx: &mut _, greeting: String) -> LyquidResult<bool> {
    *ctx.network.greeting = greeting;
    Ok(true)
}

#[method::network(export = eth)]
fn greet(ctx: &mut _) -> LyquidResult<bool> {
    *ctx.network.greet_count += 1;
    Ok(true)
}

// This network function only reads network state (`&ctx`), so it's like a "view" function in
// Solidity. You can also write `instance fn` instead, but since we don't use any instance
// state here it's good to be conservative, so you can't touch upon instance state accidentally.
#[method::network(export = eth)]
fn get_greeting_message(ctx: &_) -> LyquidResult<String> {
    Ok(format!(
        "{} I've greeted {} times to on-chain users",
        ctx.network.greeting, ctx.network.greet_count
    ))
}

// The off-chain computation below CANNOT be done by Solidity/EVM.
#[method::instance(export = eth)]
fn greet_me(ctx: &mut _) -> LyquidResult<String> {
    let mut per_user_count = ctx.instance.per_user_count.write();
    let user = per_user_count.entry(ctx.caller).or_default();
    *user += 1;
    let message = format!(
        "{} I've greeted {} times to on-chain users, and {} times to you",
        ctx.network.greeting, ctx.network.greet_count, *user
    );
    lyquid::println!("hello.greet_me: {message}");
    Ok(message)
}
